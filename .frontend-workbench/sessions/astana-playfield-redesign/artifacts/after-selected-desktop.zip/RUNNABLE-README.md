# Proposed Astana playfield

Run `npm ci` then `npm run dev`. Open `/.frontend-workbench/sessions/astana-playfield-redesign/product-design/preview/`. External OpenFreeMap services and web fonts require network access. This is a design prototype pending user review.
